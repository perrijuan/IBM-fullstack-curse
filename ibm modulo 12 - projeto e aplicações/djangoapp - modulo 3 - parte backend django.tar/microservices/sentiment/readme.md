The zip file in this directory is going to be used for Sentiment Analysis. You can find more information about this in this [link](https://www.nltk.org/data.html)
